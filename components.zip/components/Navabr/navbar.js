import React, { useState } from 'react';
import './navbar.css';
import logo from '../../assets/logo.png';
import { Link } from 'react-scroll';
import contactImg from '../../assets/contact.png';

const Navbar = () => {
  const [activeTab, setActiveTab] = useState('intro'); // Set default active tab

  const handleLinkClick = (tabName) => {
    setActiveTab(tabName);
  };

  return (
    <div>
      <nav className='navbar'>
        <img src={logo} alt="logo" className='logo' />
        <div className='desktopmenue'>
          <Link
            activeClass='active'
            to='intro'
            spy={true}
            smooth={true}
            offset={-100}
            duration={500}
            className={`desktopmenueListItem ${activeTab === 'intro' ? 'yellow' : ''}`}
            onSetActive={() => handleLinkClick('intro')}
          >
            Home
          </Link>
          <Link
            activeClass='active'
            to='skills'
            spy={true}
            smooth={true}
            offset={-100}
            duration={500}
            className={`desktopmenueListItem ${activeTab === 'skills' ? 'yellow' : ''}`}
            onSetActive={() => handleLinkClick('skills')}
          >
            About
          </Link>
          <Link
            activeClass='active'
            to='works'
            spy={true}
            smooth={true}
            offset={-100}
            duration={500}
            className={`desktopmenueListItem ${activeTab === 'works' ? 'yellow' : ''}`}
            onSetActive={() => handleLinkClick('works')}
          >
            Projects
          </Link>
        </div>
        <button
          className='desktopmenuebtn'
          onClick={() => {
            document.getElementById('contactPage').scrollIntoView({ behavior: 'smooth' });
          }}
        >
          <img src={contactImg} alt="" className='desktopmenueImg' /> Contact Me
        </button>
      </nav>
    </div>
  );
};

export default Navbar;
