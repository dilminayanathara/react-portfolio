import React from 'react'
import './project.css';
import appdev from '../../assets/project1.png';
import webdev from '../../assets/project2.jpg';
import uidev from '../../assets/project3.jpg';


const Project = () => {
  return (
    

<section id='works'>
            <h2 className="worksTitle">My Projects</h2>
            <span className="worksDesc">I have worked on a variety of design and development projects, ranging from mobile apps to responsive websites. Each project is crafted with a focus on creating intuitive user experiences and clean, functional designs.</span>
            <div className="projects-grid">
        
        <div className="project-card">
          <img src={appdev} alt="UIDesign" className="skillBarImg" />
          <h3>To-Do List App </h3>
          <p>
          A sleek and user-friendly task manager built using Java in Android Studio. This mobile app enables users to effortlessly add, update, and delete tasks, making daily organization simple and efficient.
          </p>
        </div>

        <div className="project-card">
        <img src={webdev} alt="UIDesign" className="skillBarImg" />
          <h3>Online Food Ordering System</h3>
          <p>
          A responsive and interactive web application developed using HTML, CSS, JavaScript, Bootstrap, and PHP. This system allows users to browse menus, place orders, and manage food deliveries with ease, providing a smooth and convenient online ordering experience.
          </p>
        </div>

        <div className="project-card">
        <img src={uidev} alt="UIDesign" className="skillBarImg" />
          <h3>Weather App UI/UX Design</h3>
          <p>
          A modern and intuitive weather application interface designed using Marvel. The design focuses on clear visuals, user-friendly navigation, and real-time weather updates to ensure a seamless and engaging user experience.
          </p>
        </div>

      </div>
      <button className="workBtn">See More</button>   
</section>
  );
}

export default Project;
