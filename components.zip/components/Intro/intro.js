import React from 'react'
import './intro.css';
import bg from '../../assets/person.png';


function Intro() {
  return (
    <section id="intro">
       <div className="introContent">
        <span className='hello'>Hello,</span><br></br>
        <span className='introtext'>I'm <span className='introName'>Dilmi</span><br></br>Undergraduate</span>
        <p className='introPara'>I am an undergraduate student of BICT (Hons) in Software Specialization Technology <br></br>at South Eastern University of Sri Lanka.</p>
       
        

       </div>
       <img src={bg} alt='profile' className='bg'></img>


    </section>
  )
}

export default Intro
