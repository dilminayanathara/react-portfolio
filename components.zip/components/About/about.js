import React from 'react'
import './about.css';
import appdev from '../../assets/app-design.png';
import WebDesign from '../../assets/Webdesign.png';
import UIDesign from '../../assets/ui-design.png';


const About = () => {
  return (
    <section id='skills'>
            <span className="skillTitle">About Me</span>
            <span className="skillDesc">I'm an undergraduate with a strong interest in design and development.I have skills in mobile app design and web design using modern tools and technologies.I enjoy creating clean, responsive, and user-friendly digital experiences.
            </span>
            <div className="skillBars">
                <div className="skillBar">
                    <img src={appdev} alt="AppDesign" className="skillBarImg" />
                    <div className="skillBarText">
                        <h2>Mobile App Development</h2>
                        <p>I design and develop mobile applications using Flutter and Java, focusing on clean interfaces and smooth user experiences.

.</p>
                    </div>
                </div>
                <div className="skillBar">
                    <img src={WebDesign} alt="WebDesign" className="skillBarImg" />
                    <div className="skillBarText">
                        <h2>Web Development</h2>
                        <p>I create modern and responsive websites using HTML, CSS, JavaScript, and React for the frontend.
                        For backend development, I use PHP, Laravel, and Node.js to build scalable and dynamic web applications..</p>
                    </div>
                </div>
                <div className="skillBar">
                    <img src={UIDesign} alt="UIDesign" className="skillBarImg" />
                    <div className="skillBarText">
                        <h2>UI/UX Design</h2>
                        <p>I specialize in designing user-friendly and engaging interfaces with a strong focus on usability and experience, using tools like Figma, Marvel, and Adobe XD.

.</p>
                    </div>
                </div>
            </div>
        </section>
    
  );
}

export default About
