import React from 'react'
import './contact.css';
import github from '../../assets/github.png';
import linkdin from '../../assets/linkedin.png';
import facebook from '../../assets/facebook-icon.png';
import insta from '../../assets/instagram.png';
import youtube from '../../assets/youtube.png';


const Contact = () => {
  return (
    <section id ="contactPage">

      <div id="contact">
        <h1 className='ContactPageTitle'>Contact Me</h1>
        <span className='contactDes'>I'm always open to new opportunities and collaborations—please fill out the form below to get in touch.</span>
        <form className='ContactForm'>
          <input type='text' className='name'placeholder='Name'></input>
          <input type='email' className='email'placeholder='Email'></input>
          <textarea name="message" rows="5" className='message' placeholder='Your Message'></textarea><br></br>
          <button className='submitbtn' type='submit'value='send'>submit</button>
          <div className='links'>
          <a href="https://github.com/dilminayanathara" target="_blank" rel="noopener noreferrer">
           <img src={github} alt="GitHub" className="link" />
           </a>
           <a href="https://www.linkedin.com/in/dilmi-nayanathara-97717322a" target="_blank" rel="noopener noreferrer">
          <img src={linkdin} alt="LinkedIn" className="link" />
          </a>
            <img src={facebook} alt='' className='link'></img>
            <img src={insta} alt='' className='link'></img>
            <img src={youtube} alt='' className='link'></img>
          </div>
        
        
        </form>

      </div>
    </section>
  )
}

export default Contact;
